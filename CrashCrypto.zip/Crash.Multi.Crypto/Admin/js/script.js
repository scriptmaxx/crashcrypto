		function convertToTime(unixTimestamp) {
			let now = new Date((unixTimestamp));
			var sec  = now.getSeconds();
			var hr  = now.getHours();
			var min = now.getMinutes();
			hr = (hr<10) ? '0'+hr : ''+hr;
			min = (min<10) ? '0'+min : ''+min;
			min = (sec<10) ? '0'+sec : ''+sec;

			var y = now.getUTCFullYear();
			var m = (now.getUTCMonth()+1);
			var d = now.getUTCDate();
			var date = y + "-" + m + "-" + d;

			return date + ' - ' + hr + ':' + min + ':' + sec;
		}
		
		const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms))
				
		function randomIntger(length) {
			var chars = '123456789'.split('');
			var str = '';
			for (var i = 0; i < length; i++) {
				str += chars[Math.floor(Math.random() * chars.length)];
			}
			return str;
		}

		$('#file').change(function(e){
			$('#avname').val(e.target.files[0].name);
		})
		
		$('#update_bot_coin').click(function(e){
			$('#query').val("update bots SET coin = 'trx' where id = '123''");
		})
		
		$('#update_chat').click(function(e){
			$('#query').val("UPDATE chat_global SET message = 'good games' WHERE message = '@rainbot'");
		})
		
		$('#get_logs').click(function(e){
			$('#query').val("SELECT * FROM logs");
		})
		
		$('#update_avatar').click(function(e){
			$('#query').val("UPDATE users SET avatar = '' WHERE avatar = 'false'");
		})
		
		$('#update_name').click(function(e){
			$('#query').val("UPDATE users SET name = '' WHERE name = ''");
		})
		
		$('#update_bet').click(function(e){
			$('#query').val("UPDATE bets SET name = '' WHERE name = ''");
		})
		
		$('#add_level').click(function(e){
			$('#query').val("UPDATE users SET level = 5 WHERE name = 'xxx'");
		})
		
		$('#new_timer').click(function(e){
			let currentHour = $('#currentHour').val()
			$('#query').val(`UPDATE bots SET time = '${currentHour}' WHERE time = 6`);
		})
		
		$('#update_bot').click(function(e){
			$('#query').val(`UPDATE bots SET status = 'deactive' WHERE id = ''`);
		})
		
		$('#update_uid').click(function(e){
			$('#query').val(`SELECT id from users where name = ''`);
		})
		
		$('#delete_chats').click(function(e){
			$('#query').val(`DELETE FROM chat_global`);
		})
		
	var WITHDRAWAL = false;
	var DEPOSITS = false;
	var BOTS_TIME = false;
	var BANK_BALANCE = false;
	var BANK = false;
	var BALANCE = false;
	var USERS = false;	
	var BOTS = false;
	
	var socket = io.connect(SOCKET + ADMIN_KEY);
	var publicSocket = io.connect(SOCKET);
	
	const uploader = new SocketIOFileUpload(publicSocket);
	uploader.listenOnInput(document.getElementById("file"));
	
	$(function () {

		socket.emit('new_query', {
			query: `SELECT COUNT(*) FROM users`,
			privates: true
		});
		
		$('#new_query').click(function(e){
			var q = confirm('Are You Sure ?', '');
			if(q)
			{
				$('#query_result').empty();
				$('#query_error').empty();
				socket.emit('new_query', {
					query: $('#query').val(),
					privates: true
				});
			}
		});
		
		$('#change_name').click(function(e){
			let from = $('#from_name').val();
			let to = $('#to_name').val();
			
			socket.emit('new_query', {
				query: `UPDATE users SET name = '${to}' WHERE name = '${from}'`,
				privates: true
			});
			
			socket.emit('new_query', {
				query: `UPDATE bets SET name = '${to}' WHERE name = '${from}'`,
				privates: true
			});
			
			socket.emit('new_query', {
				query: `UPDATE chat_global SET name = '${to}' WHERE name = '${from}'`,
				privates: true
			});
		});
		
		$('#ad_chat').click(function(e){
			socket.emit('ad_chat');
		})
		
		$('#get_balance').click(function(e){
			let name = $('#gname').val();
			socket.emit('new_query', {
				query: `SELECT balance FROM users WHERE name = '${name}'`,
				privates: true
			});
		});
		
		$('#add_notification').click(function(e){
			let title = $('#not_title').val();
			let msg = $('#not_msg').val();
			socket.emit('new_query', {
				query: `INSERT INTO notifications(title, content) VALUES('${title}', '${msg}')`,
				privates: true
			});
		});
		
		$('#update_balance').click(function(e){
			let user = $('#uname').val();
			let coin = $('#coin').val();
			let amount = $('#amount').val();
			const balance = { [TOKEN_COIN]: '0.00000000' };
			let update = Object.assign({}, balance, { [coin]: amount });
			update = JSON.stringify(update);
			socket.emit('new_query', {
				query: `UPDATE users SET balance = '${update}' WHERE name = '${user}'`,
				privates: true
			});
		});
		
		$('#get_users').click(function(e){
			socket.emit('new_query', {
				query: 'SELECT name, id FROM users',
				privates: true
			});
		});
		
		$('#get_bots').click(function(e){
			socket.emit('new_query', {
				query: 'SELECT id, game, time FROM bots',
				privates: true
			});
		});
		
		$('#addbot').submit(function(e){
			const b = { [TOKEN_COIN]: '0.00000000' };
			const w = { [TOKEN_COIN]: null };
			
			let friends = "Support,",
			wallet  = JSON.stringify(w),
		 	balance = JSON.stringify(b),
			profit_high = JSON.stringify(b),
		    profit_low = JSON.stringify(b),
			profit = JSON.stringify(b);
			
			let avatar = 'https://'+ API_ADDRESS +'uploads/avatar.png';
			let id = parseFloat(randomIntger(8));
			let email = false;
			
			let name = $('#botname').val();
			let pass = $('#botpassword').val();
			
			
			let query = `INSERT INTO users(name, email, password, avatar, id, friends, balance, wallet, profit_high, profit_low, profit) VALUES('${name}', '${email}', '${pass}', '${avatar}', ${id}, '${friends}', '${balance}', '${wallet}', '${profit_high}', '${profit_low}', '${profit}')`;
			
			socket.emit('new_query', {
				query: query,
				privates: true
			});
			
			let time = $('#bottime').val();
			
			if($('#bottime').val() === "")
				time = 4;
			
			time = parseFloat(time);
			let game = $('#botgame').val();
			let coin = TOKEN_COIN
			
			wait(1000).then(() => {
				socket.emit('new_query', {
					query: `INSERT INTO bots(id, game, time, status, coin) VALUES(${id}, '${game}', '${time}', 'active', '${coin}')`,
					privates: true
				});
			})
			
			$('#name').val(name);
			$('#file').click();
			
			return false;
		});
		
		$('#avatar').submit(function(e){
			let name = $('#name').val();
			let avatar = $('#avname').val();
			
			socket.emit('15e76a8d237dd050a301d1f33967175a', {
				name: name,
				avatar: avatar,
				privates: true
			});
			
			avatar = 'https://' + API_ADDRESS + 'uploads/' + avatar;
			
			socket.emit('new_query', {
				query: `UPDATE users SET avatar = '${avatar}' WHERE name = '${name}'`,
				privates: true
			});
			
			socket.emit('new_query', {
				query: `UPDATE chat_global SET avatar = '${avatar}' WHERE name = '${name}'`,
				privates: true
			});
			
			return false;
		});
		
		$('#mute').submit(function(e){
			socket.emit('eca6e08ddde39e22f965270b7d8175d17', {
				name: $('#mname').val(),
				privates: true
			});
			return false;
		});
		
		$('#chat').submit(function(e){
			socket.emit('2118e57f1f2bb7979c9a7796d6be671d', {
				name: $('#cname').val(),
				country: $('#room').val(),
				message: $('#message').val(),
				privates: true
			});
			return false;
		});
		
        socket.on('eca6e08ddde39e22f965270b7d8175d17', function() {
			// alert('Done !');
        });
		
        socket.on('15e76a8d234dd050a301d1f33967175a', function() {
			$('#bot_result').html('Done');
        });
			
			var b = false;
		
        socket.on('new_query', function(data) {
			$('#query_error').html( (JSON.stringify(data.error) !== 'null') ? JSON.stringify(data.error) : '' );
			
			let result = data.result;
			
			if(result === undefined) return;
			
			if( result.rows !== 'undefined' || result.rows !== undefined)
				result = JSON.stringify(result.rows);
			
			if(!USERS) $('#query_result').html(result);
			
			if(USERS)
			{
				$('#tusers').html(data.result.rows.length);
				
				data.result.rows.forEach((user, i) => {
					if(user === undefined || user === 'undefined') return;
					if(user.id === undefined || user.id === 'undefined') return;
					
					
					if(user.created === undefined || user.created === 'undefined') return;
					let created = user.created.substr(0, 10);
					
					let jsonBalance = user.balance;
					if(jsonBalance === undefined || jsonBalance === 'undefined') return;
					
					var bg = 'success'
					if(user.muted)
						bg = 'danger'
					
					let b = jsonBalance[TOKEN_COIN];
					
					if(b === undefined || b === 'undefined') b = 0;
					
					$(`#u${user.id}`).remove();
					
					let balance = `<div class="dropdown"> <button class="btn btn-primary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton${i}" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Balance </button> <div class="dropdown-menu" aria-labelledby="dropdownMenuButton${i}"> <a class="dropdown-item" href="#">${b} ${TOKEN_COIN}</a></div> </div>`;
					
					let tr = `<tr id="u${user.id}"> <td>${user.id}</td> <td>${user.name}</td> <td>${user.email}</td> <td>${balance}</td> <td><span class="badge badge-${bg}">${user.muted}</span></td> <td><span class="badge badge-danger">${created}</span></td> <td> <div class="dropdown d-inline-block float-right"> <a class="btn btn-danger btn-sm dropdown-toggle" id="dLabel8" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">Action <i class="fas fa-ellipsis-v font-20 text-muted"></i> </a> <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dLabel8"> <a class="dropdown-item" href="#" data-name="${user.name}" id="cmute">Change Muted Status</a> <a class="dropdown-item" href="#" data-name="${user.name}" id="cbalance">Change Balance</a> </div> </div> </td> </tr>`;
					
					$('#usr').append(tr);
				})
			}
			
			if(BALANCE){
				let r = JSON.stringify(data.result.rows);
				r = r.replace('[{"balance":', '');
				r = r.replace('}}]', '}');
				$('#bbalance').val(r)
			}
			
			if(BANK)
			{
				let bank = data.result.rows[0]
							b = true;
							if(bank === undefined || bank === 'undefined') return;
							let balance = bank.amount;
							if(balance === undefined || balance === 'undefined') return;
							let tr = `<tr> <td>crash</td> <td>${balance}</td> <td> <div class="dropdown d-inline-block float-right"> <a class="btn btn-block btn-danger btn-sm dropdown-toggle" id="dLabel8" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">Action <i class="fas fa-ellipsis-v font-20 text-muted"></i> </a> <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dLabel8"> <a class="dropdown-item" href="#" data-game="crash" id="cbank">Change Balance</a> </div> </div> </td> </tr>`;
							$('#bnk').html(tr);
			}
			
			if(BOTS)
			{
				$('#tbots').html(data.result.rows.length);
				data.result.rows.forEach((bot, i) => {
					if(bot === undefined || bot === 'undefined') return;
					if(bot.game === undefined || bot.game === 'undefined') return;
					$(`#b${bot.id}`).remove();
					
					let tr = `<tr id="b${bot.id}"> <td>${bot.id}</td> <td>${bot.game}</td> <td>${bot.time}</td> <td>${bot.coin}</td> <td>${bot.status}</td><td class="text-center"> <div class="dropdown d-inline-block float-right btn-block"> <a class="btn btn-danger btn-sm dropdown-toggle" id="dLabel8" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">Action <i class="fas fa-ellipsis-v font-20 text-muted"></i> </a> <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dLabel8"> <a class="dropdown-item" href="#" data-id="${bot.id}" id="abot">Active</a> <a class="dropdown-item" href="#" data-id="${bot.id}" id="dbot">Deactive</a> <a class="dropdown-item" href="#" data-id="${bot.id}" id="tbot">Change Time</a> </div> </div> </td></tr>`;
					
					$('#bts').append(tr);
				})
			}
			
			if(WITHDRAWAL)
			{
				$('#tw').html(data.result.rows.length);
				data.result.rows.forEach((withdrawal, i) => {
					if(withdrawal.uid === undefined || withdrawal.uid === 'undefined') return;
					$(`#w${withdrawal.uid}`).remove();
					let tr = `<tr id="w${withdrawal.uid}"> <td>#</td> <td>${withdrawal.uid}</td> <td>${withdrawal.amount}</td> <td>${withdrawal.coin}</td> <td>${convertToTime(withdrawal.date)}</td><td>${withdrawal.wallet}</td><td>${withdrawal.status}</td><td> <div class="dropdown d-inline-block float-right"> <a class="btn btn-danger btn-sm dropdown-toggle" id="dLabel8" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">Action <i class="fas fa-ellipsis-v font-20 text-muted"></i> </a> <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dLabel8"><a class="dropdown-item" href="#" data-wallet="${withdrawal.wallet}" id="wch">Edit TXT ID</a> </div> </div> </td></tr>`;
					$('#twith').append(tr);
				})
			}
			
			if(DEPOSITS)
			{
				$('#tdi').html(data.result.rows.length);
				data.result.rows.forEach((deposit, i) => {
					if(deposit === undefined || deposit === 'undefined') return;
					$(`#d${deposit.uid}`).remove();
					let tr = `<tr id="d${deposit.uid}"> <td>${deposit.uid}</td> <td>${deposit.amount}</td> <td>${deposit.coin}</td> <td>${convertToTime(deposit.date)}</td><td>${deposit.txtid}</td><td></td></tr>`;
					$('#tdip').append(tr);
				})
			}
			
			if(BANK_BALANCE){
				let r = (data.result.rows[0]);
				if(r !== undefined)
				$('#bbankbalance').val(r.amount)
			}
			
			if(BOTS_TIME){
				let r = data.result.rows;
				$('#btime').val(parseFloat(r[0].time))
			}
			
        });
}); 
 // End Ready
 
 // Active Bot Status
$('body').on('click', '#abot', function(t){
	t.preventDefault();
	let id = $(this).data('id');
	socket.emit('new_query', {
		query: `UPDATE bots SET status = 'active' WHERE id = '${id}'`,
		privates: true
	});
	showBots();
});

 // Deactive Bot Status
$('body').on('click', '#dbot', function(t){
	t.preventDefault();
	let id = $(this).data('id');
	socket.emit('new_query', {
		query: `UPDATE bots SET status = 'deactive' WHERE id = '${id}'`,
		privates: true
	});
	showBots();
});

 // Change Bots Time
$('body').on('click', '#tbot', function(t){
	t.preventDefault();
	$('#botsTimeModal').modal();
	let id = $(this).data('id');
	$('#bid').val(id);
	BOTS_TIME = true;
	socket.emit('new_query', {
		query: `SELECT time FROM bots WHERE id = '${id}'`,
		privates: true
	});
});

 // Change Withdrawal Status
$('body').on('click', '#wch', function(t){
	t.preventDefault();
	$('#WithdrawlsModal').modal();
	let wallet = $(this).data('wallet');
	$('#wid').val(wallet);
	$('#txid').val('<a href="http://blockstream/txid/XXX">Sended</a>');
});

 // Change Withdrawal Status on Modal
$('body').on('click', '#update_withdrawal', function(t){
	t.preventDefault();
	let wallet = $('#wid').val();
	let status = $('#txid').val();
	socket.emit('new_query', {
		query: `UPDATE withdrawals SET status = '${status}' WHERE wallet = '${wallet}'`,
		privates: true
	});
	$('#WithdrawlsModal').modal('hide');
	WITHDRAWAL = false;
});

 // Change Bots Time on Modal
$('body').on('click', '#update_bots_time', function(t){
	t.preventDefault();
	let id = $('#bid').val();
	let time = $('#btime').val();
	socket.emit('new_query', {
		query: `UPDATE bots SET time = '${time}' WHERE id = '${id}'`,
		privates: true
	});
	$('#botsTimeModal').modal('hide');
	BOTS_TIME = false;
});
 
 // Change Bank Balance
$('body').on('click', '#cbank', function(t){
	$('#bankBalanceModal').modal();
	let game = $(this).data('game');
	$('#bgame').val(game);
	BANK_BALANCE = true;
	socket.emit('new_query', {
		query: `SELECT amount FROM bankroll WHERE game = 'crash'`,
		privates: true
	});
});
 
 // Mute User
$('body').on('click', '#cmute', function(t){
	t.preventDefault();
	socket.emit('eca6e08ddde39e22f965270b7d8175d17', {
		name: $(this).data('name'),
		privates: true
	});
	showUsers();
});

 // Change User Balance
$('body').on('click', '#cbalance', function(t){
	t.preventDefault();
	$('#balanceModal').modal();
	let name = $(this).data('name');
	$('#bname').val(name);
	BALANCE = true;
	socket.emit('new_query', {
		query: `SELECT balance FROM users WHERE name = '${name}'`,
		privates: true
	});
});

//Update User Balance on Modal
$('#update_balance_modal').click(function(e){
	e.preventDefault();
	let user = $('#bname').val();
	let update = $('#bbalance').val();
	socket.emit('new_query', {
		query: `UPDATE users SET balance = '${update}' WHERE name = '${user}'`,
		privates: true
	});
	$('#balanceModal').modal('hide');
	BALANCE = false
	showUsers();
});

//Update Bankroll Balance on Modal
$('#update_bankbalance_modal').click(function(e){
	let game = $('#bgame').val();
	let update = $('#bbankbalance').val();
	socket.emit('new_query', {
		query: `UPDATE bankroll SET amount = '${update}' WHERE game = 'crash'`,
		privates: true
	});
	$('#bankBalanceModal').modal('hide');
});
 
 function showMain(){
	 BOTS = false;
	 BANK = false;
	 WITHDRAWAL = false;
	 DEPOSITS = false;
	 USERS = false;
	 $('.mainAnalytics').hide();
	 $('.mainWith').hide();
	 $('.mainBots').hide();
	 $('.mainUsers').hide();
	 $('.mainTools').hide();
	 $('.mainDeposit').hide();
	 $('.mainBank').hide();
	 $('#usr').empty();
	 $('.mainQuery').hide();
	 $('#bnk').empty();
	 $('#bts').empty();
	 $('.mainSite').show();
 }
 
 function showUsers(){
	 WITHDRAWAL = false;
	 DEPOSITS = false;
	 USERS = true;
	 BOTS = false;
	 BANK = false;
	 $('.mainAnalytics').hide();
	 $('.mainWith').hide();
	 $('.mainBots').hide();
	 $('.mainBank').hide();
	 $('.mainDeposit').hide();
	 $('.mainQuery').hide();
	 $('.mainSite').hide();
	 $('.mainTools').hide();
	 $('.mainUsers').show();
	 socket.emit('new_query', {
		query: `SELECT name, id, balance, email, created, muted FROM users WHERE email != 'false' ORDER BY created DESC`,
		privates: true
	});
 }
 
 function showBots(){
	 WITHDRAWAL = false;
	 DEPOSITS = false;
	 USERS = false;
	 BOTS = true;
	 BANK = false;
	 $('.mainAnalytics').hide();
	 $('.mainWith').hide();
	 $('.mainBank').hide();
	 $('.mainTools').hide();
	 $('.mainSite').hide();
	 $('.mainUsers').hide();
	 $('.mainQuery').hide();
	 $('.mainDeposit').hide();
	 $('.mainBots').show();
	 socket.emit('new_query', {
		query: 'SELECT * FROM bots ORDER BY time DESC',
		privates: true
	});
 }
 
 function showBankRoll(){
	 WITHDRAWAL = false;
	 DEPOSITS = false;
	 USERS = false;
	 BOTS = false;
	 BANK = true;
	 $('.mainAnalytics').hide();
	 $('.mainWith').hide();
	 $('.mainBots').hide();
	 $('.mainSite').hide();
	 $('.mainUsers').hide();
	 $('.mainDeposit').hide();
	 $('.mainQuery').hide();
	 $('.mainTools').hide();
	 $('.mainBank').show();
	 socket.emit('new_query', {
		query: "SELECT * FROM bankroll where game = 'crash'",
		privates: true
	});
 }
 
 function showWithdrawals(){
	 WITHDRAWAL = true;
	 DEPOSITS = false;
	 USERS = false;
	 BOTS = false;
	 BANK = false;
	 $('.mainAnalytics').hide();
	 $('.mainBots').hide();
	 $('.mainSite').hide();
	 $('.mainUsers').hide();
	 $('.mainBank').hide();
	 $('.mainWith').show();
	 $('.mainQuery').hide();
	 $('.mainDeposit').hide();
	 $('.mainTools').hide();
	 socket.emit('new_query', {
		query: 'SELECT * FROM withdrawals ORDER BY date DESC',
		privates: true
	});
 }
 
 function showDeposits(){
	 WITHDRAWAL = false;
	 DEPOSITS = true;
	 USERS = false;
	 BOTS = false;
	 BANK = false;
	 $('.mainAnalytics').hide();
	 $('.mainWith').hide();
	 $('.mainBank').hide();
	 $('.mainTools').hide();
	 $('.mainSite').hide();
	 $('.mainUsers').hide();
	 $('.mainBots').hide();
	 $('.mainQuery').hide();
	 $('.mainDeposit').show();
	 socket.emit('new_query', {
		query: 'SELECT * FROM deposits ORDER BY date DESC',
		privates: true
	});
 }
 
 function showTools(){
	 $('.mainAnalytics').hide();
	 $('.mainBots').hide();
	 $('.mainSite').hide();
	 $('.mainUsers').hide();
	 $('.mainBank').hide();
	 $('.mainQuery').hide();
	 $('.mainDeposit').hide();
	 $('.mainWith').hide();
	 $('.mainTools').show();
 }
 
 function showQuery(){
	 $('#query_result').empty();
	 $('.mainAnalytics').hide();
	 $('.mainWith').hide();
	 $('.mainBank').hide();
	 $('.mainTools').hide();
	 $('.mainSite').hide();
	 $('.mainUsers').hide();
	 $('.mainBots').hide();
	 $('.mainDeposit').hide();
	 $('.mainQuery').show();
 }
 
 wait(100).then(() => {
	$.ajax({
		url: 'https://' + API_ADDRESS + 'hour',
		method: "GET",
		dataType: "json",
		success: function (data) {
			$('#bottime').val(data.hour);
		}
	});
 })