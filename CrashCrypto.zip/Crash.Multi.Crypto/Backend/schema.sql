﻿--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.24
-- Dumped by pg_dump version 9.5.21

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: bankroll; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bankroll (
    game text,
    amount numeric DEFAULT 0
);


ALTER TABLE public.bankroll OWNER TO postgres;

--
-- Name: bets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bets (
    game text,
    gid text,
    uid bigint,
    result json,
    created timestamp with time zone DEFAULT now(),
    profit numeric,
    hash text,
    name text,
    cashout numeric,
    coin text,
    amount numeric
);


ALTER TABLE public.bets OWNER TO postgres;

--
-- Name: bots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bots (
    id numeric,
    status text,
    "time" numeric,
    coin text,
    game text
);


ALTER TABLE public.bots OWNER TO postgres;

--
-- Name: chat_global; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chat_global (
    name text,
    message text,
    date timestamp with time zone DEFAULT now(),
    uid numeric,
    "time" text,
    created timestamp with time zone DEFAULT now(),
    room text,
    sorter numeric,
    avatar text,
    level numeric DEFAULT 1
);


ALTER TABLE public.chat_global OWNER TO postgres;

--
-- Name: chat_spam; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chat_spam (
    uid numeric,
    date timestamp with time zone DEFAULT now(),
    room text,
    "time" text,
    created timestamp with time zone DEFAULT now(),
    name text,
    message text,
    sorter numeric,
    avatar text,
    level numeric DEFAULT 1
);


ALTER TABLE public.chat_spam OWNER TO postgres;

--
-- Name: crashs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crashs (
    gid text,
    busted numeric,
    hash text,
    date timestamp with time zone DEFAULT now()
);


ALTER TABLE public.crashs OWNER TO postgres;

--
-- Name: deposits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deposits (
    uid numeric,
    date timestamp with time zone DEFAULT now(),
    status text,
    txtid text,
    salt text,
    coin text,
    amount numeric
);


ALTER TABLE public.deposits OWNER TO postgres;

--
-- Name: logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logs (
    id integer,
    info text
);


ALTER TABLE public.logs OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    title text,
    content text,
    date timestamp with time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO postgres;

SET default_with_oids = true;

--
-- Name: refferals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refferals (
    uid numeric NOT NULL,
    created timestamp with time zone DEFAULT now(),
    earned numeric NOT NULL,
    username text NOT NULL
);


ALTER TABLE public.refferals OWNER TO postgres;

SET default_with_oids = false;

--
-- Name: tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tokens (
    uid numeric,
    key text
);


ALTER TABLE public.tokens OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id numeric,
    level numeric DEFAULT 1,
    avatar text,
    name text,
    token text,
    password text,
    password2 text,
    email text,
    wallet json,
    muted boolean DEFAULT false,
    created timestamp with time zone DEFAULT now(),
    profit_high json,
    profit_low json,
    max_profit json,
    profit json,
    balance json,
    friends text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: wallets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wallets (
    address text,
    uid numeric,
    coin text,
    network text
);


ALTER TABLE public.wallets OWNER TO postgres;

--
-- Name: withdrawals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.withdrawals (
    uid numeric,
    date timestamp with time zone DEFAULT now(),
    amount numeric,
    wallet text,
    status text,
    coin text
);


ALTER TABLE public.withdrawals OWNER TO postgres;

--
-- Data for Name: bankroll; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bankroll (game, amount) FROM stdin;
crash	0.00010080
\.


--
-- Data for Name: bets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bets (game, gid, uid, result, created, profit, hash, name, cashout, coin, amount) FROM stdin;
\.


--
-- Data for Name: bots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bots (id, status, "time", coin, game) FROM stdin;
\.


--
-- Data for Name: chat_global; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chat_global (name, message, date, uid, "time", created, room, sorter, avatar, level) FROM stdin;
l0zgnnzk1	Great	2021-10-02 03:51:57.674146+03	4119254418	03:51	2021-10-02 03:51:57.674146+03	\N	1633135917672	http://localhost:3004/uploads/avatar.png	1
l0zgnnzk1	Great	2021-10-02 03:51:59.136262+03	4119254418	03:51	2021-10-02 03:51:59.136262+03	\N	1633135919134	http://localhost:3004/uploads/avatar.png	1
vcb7htdmp	Great	2021-10-02 03:53:23.519346+03	6722147522	03:53	2021-10-02 03:53:23.519346+03	\N	1633136003518	http://localhost:3004/uploads/avatar.png	1
vcb7htdmp	Great	2021-10-02 03:57:07.472581+03	6722147522	03:57	2021-10-02 03:57:07.472581+03	\N	1633136227471	http://localhost:3004/uploads/avatar.png	1
\.


--
-- Data for Name: chat_spam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chat_spam (uid, date, room, "time", created, name, message, sorter, avatar, level) FROM stdin;
\.


--
-- Data for Name: crashs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.crashs (gid, busted, hash, date) FROM stdin;
\.


--
-- Data for Name: deposits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deposits (uid, date, status, txtid, salt, coin, amount) FROM stdin;
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logs (id, info) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (title, content, date) FROM stdin;
\.


--
-- Data for Name: refferals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refferals (uid, created, earned, username) FROM stdin;
\.


--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tokens (uid, key) FROM stdin;
4119254418	o2u8faezuslce5plv0at227la
6722147522	g0UjxZ1av4kBbwGSAAAC
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, level, avatar, name, token, password, password2, email, wallet, muted, created, profit_high, profit_low, max_profit, profit, balance, friends) FROM stdin;
4119254418	1	http://localhost:3004/uploads/avatar.png	l0zgnnzk1	\N	$2a$10$KptjZdc9O7bQH9TB5D992u2Gi04kTltZoudsWmDrwVrJFe.V8aWe6	l0zgnnzk1	l0zgnnzk1@gmail.com	{"fdy":null}	f	2021-10-02 03:50:14.284855+03	{"fdy":"0.00000000"}	{"fdy":"0.00000000"}	\N	{"fdy":"0.00000000"}	{"fdy":"0.00000000"}	Support,
6722147522	1	http://localhost:3004/uploads/avatar.png	vcb7htdmp	\N	$2a$10$1jqHr8MUMemaC5RrVDa8P.oD8PU61NEiPMazGsVGgJ.orFpdzCFl.	vcb7htdmp	vcb7htdmp@gmail.com	{"fdy":"0xfc7c2d2ceC70AFf4758E54e0c52E1c8665e2F40a"}	f	2021-10-02 03:53:04.607334+03	{"fdy":"0.00000000"}	{"fdy":"0.00000000"}	\N	{"fdy":"0.00000000"}	{"fdy":"0.00000000"}	Support,,l0zgnnzk1
\.


--
-- Data for Name: wallets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wallets (address, uid, coin, network) FROM stdin;
0xfc7c2d2ceC70AFf4758E54e0c52E1c8665e2F40a	6722147522	fdy	\N
\.


--
-- Data for Name: withdrawals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.withdrawals (uid, date, amount, wallet, status, coin) FROM stdin;
\.


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

