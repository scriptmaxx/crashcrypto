Crash - Production Version
-------------------

Installation Guide


Backend:

- Install Postgres Database

- Restore Database Schema:

psql -U username -f schema.sql

- Install NodeJS

Open index.js and Fill in the some details.

- npm install

- then run index.js

-------------------

FrontEnd:

Just upload all files to the server, open index.html and enter some details.
-------------------

Admin:

Open index.html and enter some details at the end of the file.

then just run admin in your system, and open index.html with your browser. dont upload admin in any server


----------
telegram : @queencentral